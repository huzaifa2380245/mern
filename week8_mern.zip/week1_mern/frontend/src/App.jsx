import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import API from "./services/api";
import "./App.css";
import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import ServicesPage from "./pages/ServicesPage";
import ServiceDetailsPage from "./pages/ServiceDetailsPage";
import DestinationDetailsPage from "./pages/DestinationDetailsPage";
import BookingFormPage from "./pages/BookingFormPage";
import BookingConfirmationPage from "./pages/BookingConfirmationPage";
import BookingsPage from "./pages/BookingsPage";
import MyReviewsPage from "./pages/MyReviewsPage";
import RecommendationsPage from "./pages/RecommendationsPage";
import AboutPage from "./pages/AboutPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import ProfilePage from "./pages/ProfilePage";
import FavoritesPage from "./pages/FavoritesPage";
import DashboardPage from "./pages/DashboardPage";

function AppContent() {
  const [destinations, setDestinations] = useState([]);
  const [error, setError] = useState("");
  const location = useLocation();

  useEffect(() => {
    API.get("/destinations")
      .then((res) => setDestinations(res.data))
      .catch(() => setError("Could not load destinations."));
  }, []);

  const isLoginPage = location.pathname === "/login" || location.pathname === "/register";

  return (
    <div className="app">
      {!isLoginPage && <Navbar />}
      {error && location.pathname === "/" && <div className="global-error">{error}</div>}
      <Routes>
        <Route path="/" element={<HomePage destinations={destinations} />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/service/:id" element={<ServiceDetailsPage />} />
        <Route path="/book/:id" element={<BookingFormPage />} />
        <Route path="/booking-confirmation/:id" element={<BookingConfirmationPage />} />
        <Route path="/recommendations" element={<RecommendationsPage />} />
        <Route path="/bookings" element={<BookingsPage />} />
        <Route path="/reviews" element={<MyReviewsPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/destination/:id" element={<DestinationDetailsPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="*" element={<div className="page-container"><h1>404</h1><p>Page not found.</p></div>} />
      </Routes>
      {!isLoginPage && <footer><h3>Travel Explorer</h3><p>Making your dream trips memorable ✈️</p></footer>}
    </div>
  );
}

export default function App() {
  return <BrowserRouter><AppContent /></BrowserRouter>;
}
