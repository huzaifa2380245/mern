import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import API from "../services/api";

function BookingForm() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [service, setService] = useState(null);
  const [bookingDate, setBookingDate] = useState("");
  const [numberOfPeople, setNumberOfPeople] = useState(1);
  const [specialRequest, setSpecialRequest] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    API.get(`/services/${id}`)
      .then((res) => {
        setService(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [id]);

  const totalPrice = service
    ? service.price * numberOfPeople
    : 0;

  const handleBooking = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
      return;
    }

    if (!bookingDate) {
      setMessage("Please select a booking date.");
      return;
    }

    if (numberOfPeople < 1) {
      setMessage("Number of people must be at least 1.");
      return;
    }

    try {
      setLoading(true);
      const res = await API.post(
        "/bookings",
        {
          serviceId: id,
          bookingDate,
          numberOfPeople,
          specialRequest
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      navigate(
        `/booking-confirmation/${res.data.booking._id}`
      );

    } catch (error) {
      setMessage(
        error.response?.data?.message ||
        "Booking failed"
      );
    } finally {
      setLoading(false);
    }
  };

  if (!service) {
    return <p>Loading booking form...</p>;
  }

  return (
    <section className="booking-page">

      <h1>Book Your Trip</h1>

      <div className="booking-card">

        <h2>{service.serviceName}</h2>

        <p>📍 {service.location}</p>

        <p>
          💰 Price per person: PKR {service.price}
        </p>

        <form onSubmit={handleBooking}>

          <label>Booking Date</label>

          <input
            type="date"
            value={bookingDate}
            onChange={(e) =>
              setBookingDate(e.target.value)
            }
            required
          />

          <label>Number of People</label>

          <input
            type="number"
            min="1"
            value={numberOfPeople}
            onChange={(e) =>
              setNumberOfPeople(
                Number(e.target.value)
              )
            }
            required
          />

          <label>Special Request</label>

          <textarea
            placeholder="Any special requests?"
            value={specialRequest}
            onChange={(e) =>
              setSpecialRequest(e.target.value)
            }
          />

          <div className="booking-summary">

            <h3>Booking Summary</h3>

            <p>
              People: {numberOfPeople}
            </p>

            <p>
              Price per person: PKR {service.price}
            </p>

            <h2>
              Total: PKR {totalPrice}
            </h2>

          </div>

          <button type="submit" disabled={loading}>
            {loading ? "Booking..." : "Confirm Booking"}
          </button>

        </form>

        {message && <p>{message}</p>}

      </div>

    </section>
  );
}

export default BookingForm;