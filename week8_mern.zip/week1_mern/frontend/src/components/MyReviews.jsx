import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Stars({ value, interactive = false, onChange }) {
  return <div className="review-stars">{[1,2,3,4,5].map((star) => interactive ? (
    <button type="button" key={star} className={star <= value ? "star active" : "star"} onClick={() => onChange(star)}>★</button>
  ) : <span key={star}>{star <= value ? "★" : "☆"}</span>)}</div>;
}

function MyReviews() {
  const [reviews, setReviews] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editRating, setEditRating] = useState(5);
  const [editText, setEditText] = useState("");
  const [editImage, setEditImage] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const load = async () => {
    try {
      setLoading(true);
      const res = await API.get("/reviews/mine");
      setReviews(res.data.reviews || []);
    } catch (err) {
      setError(err.response?.data?.message || "Could not load your reviews.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const startEdit = (review) => {
    setEditingId(review._id);
    setEditRating(review.rating);
    setEditText(review.reviewText);
    setEditImage(review.image || "");
    setMessage("");
    setError("");
  };

  const saveEdit = async (id) => {
    if (!editRating || !editText.trim()) {
      setError("Rating and review text are required.");
      return;
    }
    try {
      const res = await API.put(`/reviews/${id}`, { rating: editRating, reviewText: editText, image: editImage });
      setReviews((items) => items.map((item) => item._id === id ? res.data : item));
      setEditingId(null);
      setMessage("Review updated successfully.");
    } catch (err) {
      setError(err.response?.data?.message || "Could not update review.");
    }
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this review?")) return;
    try {
      await API.delete(`/reviews/${id}`);
      setReviews((items) => items.filter((item) => item._id !== id));
      setMessage("Review deleted successfully.");
    } catch (err) {
      setError(err.response?.data?.message || "Could not delete review.");
    }
  };

  if (loading) return <main className="page-container"><p>Loading your reviews...</p></main>;

  return (
    <main className="page-container">
      <h1>My Reviews</h1>
      {message && <div className="review-success">{message}</div>}
      {error && <div className="review-error">{error}</div>}
      {reviews.length === 0 ? (
        <div className="empty-panel">You have not written any reviews yet.</div>
      ) : reviews.map((review) => {
        const destination = review.destination;
        const service = review.service;
        const targetUrl = destination ? `/destination/${destination._id}` : `/service/${service?._id}`;
        const targetName = destination?.name || service?.serviceName || "Travel item";
        return (
          <article key={review._id} className="my-review-card">
            {editingId === review._id ? (
              <div style={{ width: "100%" }}>
                <h3>{targetName}</h3>
                <Stars value={editRating} interactive onChange={setEditRating} />
                <textarea value={editText} onChange={(e) => setEditText(e.target.value)} maxLength={1000} />
                <input type="url" value={editImage} onChange={(e) => setEditImage(e.target.value)} placeholder="Image URL (optional)" />
                <div className="review-actions">
                  <button className="review-submit" onClick={() => saveEdit(review._id)}>Save</button>
                  <button className="review-cancel" onClick={() => setEditingId(null)}>Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div>
                  <h3>{targetName}</h3>
                  <Stars value={review.rating} />
                  <p>{review.reviewText}</p>
                  <small>{new Date(review.createdAt).toLocaleDateString()}</small>
                </div>
                <div className="review-actions">
                  <Link className="view-btn" to={targetUrl}>View</Link>
                  <button className="review-submit" onClick={() => startEdit(review)}>Edit</button>
                  <button className="review-cancel" onClick={() => remove(review._id)}>Delete</button>
                </div>
              </>
            )}
          </article>
        );
      })}
    </main>
  );
}

export default MyReviews;
