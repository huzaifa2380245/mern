import { Link } from "react-router-dom";

function Navbar() {
  const token = localStorage.getItem("token");
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    window.location.href = "/login";
  };

  return (
    <nav className="navbar">
      <h2 className="brand">🌍 Travel Explorer</h2>
      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/services">Services</Link>
        {token && <Link to="/recommendations">For You</Link>}
        {token && <Link to="/favorites">Favorites</Link>}
        {token && <Link to="/bookings">My Bookings</Link>}
        {token && <Link to="/reviews">My Reviews</Link>}
        {token && <Link to="/profile">Profile</Link>}
        <Link to="/about">About</Link>
        {!token ? <> <Link to="/login">Login</Link><Link to="/register">Register</Link> </> : <button onClick={handleLogout}>Logout</button>}
      </div>
    </nav>
  );
}
export default Navbar;
