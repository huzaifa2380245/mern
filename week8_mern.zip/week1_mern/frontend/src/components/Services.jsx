import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Services() {
  const [services, setServices] = useState([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    API.get("/services")
      .then((res) => setServices(res.data))
      .catch((err) => setError(err.response?.data?.message || "Could not load services."))
      .finally(() => setLoading(false));
  }, []);

  const categories = ["All", ...new Set(services.map((service) => service.category).filter(Boolean))];

  const filteredServices = useMemo(() => services.filter((service) => {
    const text = search.toLowerCase();
    const matchesSearch = !text || `${service.serviceName} ${service.category} ${service.location}`.toLowerCase().includes(text);
    const matchesCategory = category === "All" || service.category === category;
    return matchesSearch && matchesCategory;
  }), [services, search, category]);

  return (
    <section className="services-page">
      <h1 className="title">Travel Services</h1>
      <p className="services-subtitle">Choose a service and start planning your next trip.</p>
      <input className="search-input" placeholder="Search services..." value={search} onChange={(e) => setSearch(e.target.value)} />
      <div className="category-filter">
        {categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={category === item ? "active-category" : ""}>{item}</button>)}
      </div>

      {loading ? <p>Loading services...</p> : error ? <p className="global-error">{error}</p> : (
        <div className="card-container">
          {filteredServices.length ? filteredServices.map((service) => (
            <div className="card" key={service._id}>
              <img src={service.image} alt={service.serviceName} />
              <div className="card-content">
                <h3>{service.serviceName}</h3>
                <p>📍 {service.location}</p>
                <p>🏷️ {service.category}</p>
                <p>⭐ Rating: {service.rating || 0}</p>
                <p>💰 PKR {service.price}</p>
                <p>{service.availability ? "✅ Available" : "❌ Not Available"}</p>
                <Link to={`/service/${service._id}`} className="view-btn">View Details</Link>
              </div>
            </div>
          )) : <p>No services found.</p>}
        </div>
      )}
    </section>
  );
}

export default Services;
