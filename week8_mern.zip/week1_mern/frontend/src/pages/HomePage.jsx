import Hero from "../components/Hero";
import Categories from "../components/Categories";
import Destinations from "../components/Destination";
export default function HomePage({ destinations }) { return <><Hero /><Categories /><Destinations destinations={destinations} /></>; }
