import DestinationDetails from "../components/DestinationDetails";
export default function DestinationDetailsPage(){ return <DestinationDetails />; }
