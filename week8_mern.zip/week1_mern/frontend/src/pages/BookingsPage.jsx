import BookingHistory from "../components/BookingHistory";
export default function BookingsPage(){ return <BookingHistory />; }
