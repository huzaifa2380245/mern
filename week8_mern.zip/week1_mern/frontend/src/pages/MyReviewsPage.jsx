import MyReviews from "../components/MyReviews";
import "../components/MyReviews.css";
export default function MyReviewsPage(){ return <MyReviews />; }
