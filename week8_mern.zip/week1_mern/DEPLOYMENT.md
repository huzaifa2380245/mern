# Deployment Checklist

This project is ready to deploy, but deployment requires your own hosting accounts and MongoDB connection string.

## Backend
Deploy `Backend` to a Node.js host such as Render, Railway, or another Node-compatible service.
Set:
- `MONGO_URI`
- `PORT`
- `JWT_SECRET`
- `FRONTEND_URL` (optional for stricter CORS)

The health endpoint is `GET /api/health`.

## Frontend
Deploy `frontend` to a static host such as Vercel, Netlify, or another Vite-compatible service.
Update `frontend/src/services/api.js` so `baseURL` points to the deployed backend `/api` URL.

## MongoDB
Use MongoDB Atlas or another MongoDB host and add the deployed backend server IP/network access as required by your provider.
