const Destination = require("../models/Destination");

exports.getDestinations = async (req, res) => {
  try {
    const { search, category, location } = req.query;
    const filter = {};
    if (category && category !== "All") filter.category = category;
    if (location) filter.$or = [
      { city: { $regex: location, $options: "i" } },
      { country: { $regex: location, $options: "i" } }
    ];
    if (search) {
      filter.$and = [
        ...(filter.$and || []),
        { $or: [
          { name: { $regex: search, $options: "i" } },
          { city: { $regex: search, $options: "i" } },
          { country: { $regex: search, $options: "i" } },
          { description: { $regex: search, $options: "i" } }
        ] }
      ];
    }
    const destinations = await Destination.find(filter).sort({ featured: -1, popularity: -1, rating: -1 });
    res.json(destinations);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getDestination = async (req, res) => {
  try {
    const destination = await Destination.findById(req.params.id);
    if (!destination) return res.status(404).json({ message: "Destination not found" });
    res.json(destination);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createDestination = async (req, res) => {
  try {
    const destination = await Destination.create(req.body);
    res.status(201).json(destination);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateDestination = async (req, res) => {
  try {
    const destination = await Destination.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!destination) return res.status(404).json({ message: "Destination not found" });
    res.json(destination);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteDestination = async (req, res) => {
  try {
    const destination = await Destination.findByIdAndDelete(req.params.id);
    if (!destination) return res.status(404).json({ message: "Destination not found" });
    res.json({ message: "Destination deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getDestinationsByCategory = async (req, res) => {
  try {
    res.json(await Destination.find({ category: req.params.category }));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
