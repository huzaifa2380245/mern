const Service = require("../models/Service");

exports.getServices = async (req, res) => {
  try {
    const { search, category, location } = req.query;
    const filter = {};
    if (category && category !== "All") filter.category = category;
    if (location) filter.location = { $regex: location, $options: "i" };
    if (search) filter.$or = [
      { serviceName: { $regex: search, $options: "i" } },
      { category: { $regex: search, $options: "i" } },
      { location: { $regex: search, $options: "i" } },
      { description: { $regex: search, $options: "i" } }
    ];
    res.json(await Service.find(filter).sort({ availability: -1, rating: -1 }));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getServiceById = async (req, res) => {
  try {
    const service = await Service.findById(req.params.id);
    if (!service) return res.status(404).json({ message: "Service not found" });
    res.json(service);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.addService = async (req, res) => {
  try {
    res.status(201).json(await Service.create(req.body));
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.updateService = async (req, res) => {
  try {
    const service = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!service) return res.status(404).json({ message: "Service not found" });
    res.json(service);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteService = async (req, res) => {
  try {
    const service = await Service.findByIdAndDelete(req.params.id);
    if (!service) return res.status(404).json({ message: "Service not found" });
    res.json({ message: "Service deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getServicesByCategory = async (req, res) => {
  try {
    res.json(await Service.find({ category: req.params.category }));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
