const Booking = require("../models/Booking");
const Service = require("../models/Service");

exports.createBooking = async (req, res) => {
  try {
    const { serviceId, bookingDate, numberOfPeople, specialRequest } = req.body || {};
    if (!serviceId || !bookingDate || !numberOfPeople) return res.status(400).json({ message: "Service, booking date and number of people are required" });
    const people = Number(numberOfPeople);
    if (!Number.isInteger(people) || people < 1) return res.status(400).json({ message: "Number of people must be at least 1" });
    const date = new Date(bookingDate);
    if (Number.isNaN(date.getTime())) return res.status(400).json({ message: "Invalid booking date" });
    if (date < new Date()) return res.status(400).json({ message: "Booking date must be in the future" });

    const service = await Service.findById(serviceId);
    if (!service) return res.status(404).json({ message: "Service not found" });
    if (!service.availability) return res.status(400).json({ message: "Service is not available" });

    const booking = await Booking.create({
      user: req.user.userId,
      service: serviceId,
      bookingDate: date,
      numberOfPeople: people,
      totalPrice: service.price * people,
      specialRequest: specialRequest || "",
      bookingStatus: "Pending",
      bookingId: "BK" + Date.now()
    });

    res.status(201).json({ message: "Booking created successfully", booking });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.getUserBookings = async (req, res) => {
  try {
    res.json(await Booking.find({ user: req.user.userId }).populate("service").sort({ createdAt: -1 }));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getSingleBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.user.userId }).populate("service");
    if (!booking) return res.status(404).json({ message: "Booking not found" });
    res.json(booking);
  } catch (error) {
    res.status(400).json({ message: "Invalid booking ID" });
  }
};

exports.updateBooking = async (req, res) => {
  try {
    const allowed = {};
    if (req.body.bookingDate) allowed.bookingDate = req.body.bookingDate;
    if (req.body.numberOfPeople) allowed.numberOfPeople = req.body.numberOfPeople;
    if (req.body.specialRequest !== undefined) allowed.specialRequest = req.body.specialRequest;
    const booking = await Booking.findOneAndUpdate({ _id: req.params.id, user: req.user.userId }, allowed, { new: true, runValidators: true });
    if (!booking) return res.status(404).json({ message: "Booking not found" });
    res.json({ message: "Booking updated successfully", booking });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findOneAndUpdate({ _id: req.params.id, user: req.user.userId, bookingStatus: { $ne: "Cancelled" } }, { bookingStatus: "Cancelled" }, { new: true });
    if (!booking) return res.status(404).json({ message: "Booking not found or already cancelled" });
    res.json({ message: "Booking cancelled successfully", booking });
  } catch (error) {
    res.status(400).json({ message: "Invalid booking ID" });
  }
};
