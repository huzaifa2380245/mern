const mongoose = require("mongoose");
const Review = require("../models/Review");

const buildFilter = (query) => {
  const filter = {};
  if (query.destination && mongoose.isValidObjectId(query.destination)) filter.destination = query.destination;
  if (query.service && mongoose.isValidObjectId(query.service)) filter.service = query.service;
  return filter;
};

const validateReviewInput = ({ rating, reviewText }) => {
  if (rating === undefined || rating === "") return "Rating is required";
  const numericRating = Number(rating);
  if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) return "Rating must be between 1 and 5";
  if (!reviewText || !reviewText.trim()) return "Review text is required";
  if (reviewText.trim().length > 1000) return "Review text cannot exceed 1000 characters";
  return null;
};

const addReview = async (req, res) => {
  try {
    const { destination, service, rating, reviewText, image } = req.body;
    const validationError = validateReviewInput({ rating, reviewText });
    if (validationError) return res.status(400).json({ message: validationError });
    if (!destination && !service) return res.status(400).json({ message: "Destination or service is required" });
    if (destination && service) return res.status(400).json({ message: "Choose either a destination or a service" });

    const target = destination || service;
    const duplicateFilter = { user: req.user.userId, ...(destination ? { destination } : { service }) };
    const existingReview = await Review.findOne(duplicateFilter);
    if (existingReview) return res.status(409).json({ message: "You have already reviewed this item" });

    const review = await Review.create({
      user: req.user.userId,
      destination: destination || undefined,
      service: service || undefined,
      rating: Number(rating),
      reviewText: reviewText.trim(),
      image: image || ""
    });

    const savedReview = await Review.findById(review._id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName");

    res.status(201).json(savedReview);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getReviews = async (req, res) => {
  try {
    const filter = buildFilter(req.query);
    const reviews = await Review.find(filter)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName")
      .sort({ createdAt: -1 });

    const totalReviews = reviews.length;
    const averageRating = totalReviews
      ? Number((reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews).toFixed(1))
      : 0;

    const ratingDistribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach((review) => { ratingDistribution[review.rating] += 1; });

    res.json({
      reviews,
      summary: { averageRating, totalReviews, ratingDistribution }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getMyReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ user: req.user.userId })
      .populate("destination", "name city country")
      .populate("service", "serviceName location")
      .sort({ createdAt: -1 });
    res.json({ reviews });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getReviewById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid review ID" });
    const review = await Review.findById(req.params.id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName");
    if (!review) return res.status(404).json({ message: "Review not found" });
    res.json(review);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateReview = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid review ID" });
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ message: "Review not found" });
    if (review.user.toString() !== req.user.userId) return res.status(403).json({ message: "You can only update your own review" });

    const { rating, reviewText, image } = req.body;
    const validationError = validateReviewInput({ rating, reviewText });
    if (validationError) return res.status(400).json({ message: validationError });

    review.rating = Number(rating);
    review.reviewText = reviewText.trim();
    review.image = image || "";
    await review.save();

    res.json(await Review.findById(review._id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName"));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const deleteReview = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid review ID" });
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ message: "Review not found" });
    if (review.user.toString() !== req.user.userId) return res.status(403).json({ message: "You can only delete your own review" });
    await review.deleteOne();
    res.json({ message: "Review deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const markHelpful = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid review ID" });
    const review = await Review.findByIdAndUpdate(req.params.id, { $inc: { helpfulCount: 1 } }, { new: true });
    if (!review) return res.status(404).json({ message: "Review not found" });
    res.json({ message: "Marked as helpful", helpfulCount: review.helpfulCount });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { addReview, getReviews, getMyReviews, getReviewById, updateReview, deleteReview, markHelpful };
