const express = require("express");
const router = express.Router();
const User = require("../models/User");
const {
  register,
  login,
  getProfile,
  updateProfile,
  addFavorite,
  removeFavorite,
  getFavorites,
  addRecentlyViewed
} = require("../controllers/authController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/", (req, res) => res.json({ message: "Auth API is working" }));
router.get("/users", async (req, res) => {
  try {
    res.json(await User.find().select("-password"));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
router.post("/register", register);
router.post("/login", login);
router.get("/profile", authMiddleware, getProfile);
router.put("/profile", authMiddleware, updateProfile);
router.post("/favorites/:destinationId", authMiddleware, addFavorite);
router.delete("/favorites/:destinationId", authMiddleware, removeFavorite);
router.get("/favorites", authMiddleware, getFavorites);
router.post("/recently-viewed/:destinationId", authMiddleware, addRecentlyViewed);

module.exports = router;
