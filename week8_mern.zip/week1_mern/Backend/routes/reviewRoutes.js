const express = require("express");
const router = express.Router();
const {
  addReview,
  getReviews,
  getMyReviews,
  getReviewById,
  updateReview,
  deleteReview,
  markHelpful
} = require("../controllers/reviewController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/", getReviews);
router.get("/mine", authMiddleware, getMyReviews);
router.post("/", authMiddleware, addReview);
router.patch("/:id/helpful", markHelpful);
router.put("/:id", authMiddleware, updateReview);
router.delete("/:id", authMiddleware, deleteReview);
router.get("/:id", getReviewById);

module.exports = router;
