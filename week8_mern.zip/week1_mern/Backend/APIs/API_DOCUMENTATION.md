# Travel Explorer API Documentation

Base URL: `http://localhost:5000/api`

## Authentication
- `POST /auth/register` - register user
- `POST /auth/login` - login and receive JWT
- `GET /auth/profile` - protected profile
- `PUT /auth/profile` - update profile
- `GET /auth/favorites` - protected favorites
- `POST /auth/favorites/:destinationId` - add favorite
- `DELETE /auth/favorites/:destinationId` - remove favorite
- `POST /auth/recently-viewed/:destinationId` - record recently viewed destination

## Destinations
- `GET /destinations`
- `GET /destinations?search=hunza&category=Mountain&location=Pakistan`
- `GET /destinations/:id`
- `GET /destinations/category/:category`
- `POST /destinations`
- `PUT /destinations/:id`
- `DELETE /destinations/:id`

## Services
- `GET /services`
- `GET /services?search=tour&category=Adventure&location=Skardu`
- `GET /services/:id`
- `GET /services/category/:category`
- `POST /services`
- `PUT /services/:id`
- `DELETE /services/:id`

## Bookings
Protected with JWT.
- `POST /bookings`
- `GET /bookings`
- `GET /bookings/:id`
- `PUT /bookings/:id`
- `PATCH /bookings/:id/cancel`

## Reviews
- `GET /reviews?destination=:id`
- `GET /reviews?service=:id`
- `GET /reviews/:id`
- `GET /reviews/mine` - protected user's reviews
- `POST /reviews` - protected
- `PUT /reviews/:id` - protected owner only
- `DELETE /reviews/:id` - protected owner only
- `PATCH /reviews/:id/helpful`

Review responses include average rating, total reviews, and 1-5 star distribution.

## Recommendations
Protected with JWT.
- `GET /recommendations/preferences`
- `POST /recommendations/preferences`
- `PUT /recommendations/preferences`
- `GET /recommendations`

Recommendations use budget, travel style, category, location, trip duration, favorites, recently viewed destinations, and previous booking interests.
