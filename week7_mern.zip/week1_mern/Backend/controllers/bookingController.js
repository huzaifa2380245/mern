const Booking = require("../models/Booking");
const Service = require("../models/Service");

// Create Booking
exports.createBooking = async (req, res) => {
    try {
        const {
            serviceId,
            bookingDate,
            numberOfPeople,
            specialRequest
        } = req.body;

        // Check service
        const service = await Service.findById(serviceId);

        if (!service) {
            return res.status(404).json({
                message: "Service not found"
            });
        }

        // Check availability
        if (!service.availability) {
            return res.status(400).json({
                message: "Service is not available"
            });
        }

        // Calculate total price
        const totalPrice =
            service.price * numberOfPeople;

        // Generate booking ID
        const bookingId =
            "BK" + Date.now();

        const booking = await Booking.create({
            user: req.user.userId,
            service: serviceId,
            bookingDate,
            numberOfPeople,
            totalPrice,
            specialRequest,
            bookingStatus: "Pending",
            bookingId
        });

        res.status(201).json({
            message: "Booking created successfully",
            booking
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Get User Bookings
exports.getUserBookings = async (req, res) => {
    try {
        const bookings = await Booking.find({
            user: req.user.userId
        })
            .populate("service")
            .sort({ createdAt: -1 });

        res.json(bookings);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Get Single Booking
exports.getSingleBooking = async (req, res) => {
    try {
        const booking = await Booking.findOne({
            _id: req.params.id,
            user: req.user.userId
        }).populate("service");

        if (!booking) {
            return res.status(404).json({
                message: "Booking not found"
            });
        }

        res.json(booking);

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Update Booking
exports.updateBooking = async (req, res) => {
    try {
        const booking = await Booking.findOneAndUpdate(
            {
                _id: req.params.id,
                user: req.user.userId
            },
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!booking) {
            return res.status(404).json({
                message: "Booking not found"
            });
        }

        res.json({
            message: "Booking updated successfully",
            booking
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Cancel Booking
exports.cancelBooking = async (req, res) => {
    try {
        const booking = await Booking.findOneAndUpdate(
            {
                _id: req.params.id,
                user: req.user.userId
            },
            {
                bookingStatus: "Cancelled"
            },
            {
                new: true
            }
        );

        if (!booking) {
            return res.status(404).json({
                message: "Booking not found"
            });
        }

        res.json({
            message: "Booking cancelled successfully",
            booking
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};