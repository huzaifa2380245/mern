const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Register
exports.register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).json({
                message: "Email already registered"
            });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            name,
            email,
            password: hashedPassword
        });

        res.status(201).json({
            message: "Registration successful",
            user: {
                id: user._id,
                name: user.name,
                email: user.email
            }
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};

// Login
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({
                message: "Invalid email or password"
            });
        }

        const passwordMatch = await bcrypt.compare(
            password,
            user.password
        );

        if (!passwordMatch) {
            return res.status(400).json({
                message: "Invalid email or password"
            });
        }

        const token = jwt.sign(
            { userId: user._id },
            process.env.JWT_SECRET,
            { expiresIn: "7d" }
        );

        res.json({
            message: "Login successful",
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email
            }
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};
// Get Profile
exports.getProfile = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId).select("-password");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.json({
            user
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};
// Add to Favorites
exports.addFavorite = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const destinationId = req.params.destinationId;

        if (user.favorites.includes(destinationId)) {
            return res.status(400).json({
                message: "Destination already in favorites"
            });
        }

        user.favorites.push(destinationId);

        await user.save();

        res.json({
            message: "Destination added to favorites",
            favorites: user.favorites
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Remove from Favorites
exports.removeFavorite = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const destinationId = req.params.destinationId;

        user.favorites = user.favorites.filter(
            (id) => id.toString() !== destinationId
        );

        await user.save();

        res.json({
            message: "Destination removed from favorites",
            favorites: user.favorites
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};


// Get Favorites
exports.getFavorites = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId)
            .populate("favorites");

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        res.json({
            favorites: user.favorites
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};
// Add Recently Viewed
exports.addRecentlyViewed = async (req, res) => {
    try {
        const user = await User.findById(req.user.userId);

        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        const destinationId = req.params.destinationId;

        // Remove if already exists
        user.recentlyViewed = user.recentlyViewed.filter(
            (id) => id.toString() !== destinationId
        );

        // Add to beginning
        user.recentlyViewed.unshift(destinationId);

        // Keep only latest 5
        user.recentlyViewed = user.recentlyViewed.slice(0, 5);

        await user.save();

        res.json({
            message: "Recently viewed updated",
            recentlyViewed: user.recentlyViewed
        });

    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
};