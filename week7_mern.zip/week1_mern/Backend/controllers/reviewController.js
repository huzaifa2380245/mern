const Review = require("../models/Review");

const buildFilter = (query) => {
  const filter = {};

  if (query.destination) {
    filter.destination = query.destination;
  }

  if (query.service) {
    filter.service = query.service;
  }

  return filter;
};

// Add Review
const addReview = async (req, res) => {
  try {
    const { destination, service, rating, reviewText, image } = req.body;

    if (!rating) {
      return res.status(400).json({
        message: "Rating is required"
      });
    }

    const numericRating = Number(rating);

    if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
      return res.status(400).json({
        message: "Rating must be between 1 and 5"
      });
    }

    if (!reviewText || !reviewText.trim()) {
      return res.status(400).json({
        message: "Review text is required"
      });
    }

    if (!destination && !service) {
      return res.status(400).json({
        message: "Destination or service is required"
      });
    }

    if (destination && service) {
      return res.status(400).json({
        message: "Choose either a destination or a service"
      });
    }

    const review = await Review.create({
      user: req.user.userId,
      destination: destination || null,
      service: service || null,
      rating: numericRating,
      reviewText: reviewText.trim(),
      image: image || ""
    });

    const savedReview = await Review.findById(review._id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName");

    res.status(201).json(savedReview);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Get Reviews
const getReviews = async (req, res) => {
  try {
    const filter = buildFilter(req.query);

    const reviews = await Review.find(filter)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName")
      .sort({ createdAt: -1 });

    const totalReviews = reviews.length;

    const averageRating = totalReviews
      ? Number(
          (
            reviews.reduce((sum, review) => sum + review.rating, 0) /
            totalReviews
          ).toFixed(1)
        )
      : 0;

    const ratingDistribution = {
      5: 0,
      4: 0,
      3: 0,
      2: 0,
      1: 0
    };

    reviews.forEach((review) => {
      ratingDistribution[review.rating] += 1;
    });

    res.json({
      reviews,
      summary: {
        averageRating,
        totalReviews,
        ratingDistribution
      }
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Get Review By ID
const getReviewById = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName");

    if (!review) {
      return res.status(404).json({
        message: "Review not found"
      });
    }

    res.json(review);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Update Review
const updateReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({
        message: "Review not found"
      });
    }

    if (review.user.toString() !== req.user.userId) {
      return res.status(403).json({
        message: "You can only update your own review"
      });
    }

    const { rating, reviewText, image } = req.body;

    if (!rating) {
      return res.status(400).json({
        message: "Rating is required"
      });
    }

    const numericRating = Number(rating);

    if (!Number.isInteger(numericRating) || numericRating < 1 || numericRating > 5) {
      return res.status(400).json({
        message: "Rating must be between 1 and 5"
      });
    }

    if (!reviewText || !reviewText.trim()) {
      return res.status(400).json({
        message: "Review text is required"
      });
    }

    review.rating = numericRating;
    review.reviewText = reviewText.trim();
    review.image = image || "";

    await review.save();

    const updatedReview = await Review.findById(review._id)
      .populate("user", "name")
      .populate("destination", "name")
      .populate("service", "serviceName");

    res.json(updatedReview);
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Delete Review
const deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);

    if (!review) {
      return res.status(404).json({
        message: "Review not found"
      });
    }

    if (review.user.toString() !== req.user.userId) {
      return res.status(403).json({
        message: "You can only delete your own review"
      });
    }

    await review.deleteOne();

    res.json({
      message: "Review deleted successfully"
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

// Helpful button
const markHelpful = async (req, res) => {
  try {
    const review = await Review.findByIdAndUpdate(
      req.params.id,
      { $inc: { helpfulCount: 1 } },
      { new: true }
    ).populate("user", "name");

    if (!review) {
      return res.status(404).json({
        message: "Review not found"
      });
    }

    res.json({
      message: "Marked as helpful",
      helpfulCount: review.helpfulCount
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
};

module.exports = {
  addReview,
  getReviews,
  getReviewById,
  updateReview,
  deleteReview,
  markHelpful
};
