const RecommendationPreference = require("../models/RecommendationPreference");
const Destination = require("../models/Destination");
const Service = require("../models/Service");
const User = require("../models/User");
const Booking = require("../models/Booking");

const allowedStyles = [
  "Adventure",
  "Relaxation",
  "Cultural",
  "Family",
  "Nature",
  "Luxury",
  "Budget",
  "Sightseeing"
];

const validatePreferences = (data) => {
  const { budget, travelStyle, preferredCategory, preferredLocation, tripDuration } = data;

  if (budget === undefined || budget === "" || Number.isNaN(Number(budget)) || Number(budget) < 0) {
    return "Budget must be a valid non-negative number.";
  }

  if (!allowedStyles.includes(travelStyle)) {
    return "Please select a valid travel style.";
  }

  if (!preferredCategory || !preferredCategory.trim()) {
    return "Preferred category is required.";
  }

  if (!preferredLocation || !preferredLocation.trim()) {
    return "Preferred location is required.";
  }

  if (
    tripDuration === undefined ||
    tripDuration === "" ||
    !Number.isInteger(Number(tripDuration)) ||
    Number(tripDuration) < 1 ||
    Number(tripDuration) > 60
  ) {
    return "Trip duration must be a whole number between 1 and 60 days.";
  }

  return null;
};

const normalize = (value) => String(value || "").trim().toLowerCase();

const includesText = (value, target) => {
  const a = normalize(value);
  const b = normalize(target);
  return Boolean(a && b && (a.includes(b) || b.includes(a)));
};

const inferStyles = (item, type) => {
  const values = Array.isArray(item.travelStyles) ? item.travelStyles : [];
  if (values.length) return values.map(normalize);

  const text = normalize(
    `${item.category || ""} ${item.serviceName || item.name || ""} ${
      type === "service" ? (item.features || []).join(" ") : ""
    }`
  );

  const styles = [];

  if (/(adventure|mountain|trek|camp|hiking)/.test(text)) styles.push("adventure");
  if (/(beach|relax|resort|spa|island)/.test(text)) styles.push("relaxation");
  if (/(culture|cultural|city|heritage|museum|history)/.test(text)) styles.push("cultural");
  if (/(family|kids)/.test(text)) styles.push("family");
  if (/(nature|forest|lake|valley|mountain)/.test(text)) styles.push("nature");
  if (/(luxury|premium|five star)/.test(text)) styles.push("luxury");
  if (/(budget|cheap|affordable)/.test(text)) styles.push("budget");
  if (/(tour|sightseeing|guide|attractions)/.test(text)) styles.push("sightseeing");

  return [...new Set(styles)];
};

const getCost = (item, type) => {
  if (type === "service") return Number(item.price || 0);
  return Number(item.budget || 0);
};

const getDuration = (item) => Number(item.duration || 0);

const scoreItem = (item, type, preferences, user) => {
  let score = 0;
  const reasons = [];
  const maxScore = 15;
  const preferredStyle = normalize(preferences.travelStyle);
  const preferredCategory = normalize(preferences.preferredCategory);
  const preferredLocation = normalize(preferences.preferredLocation);
  const styles = inferStyles(item, type);
  const category = normalize(item.category);
  const location = normalize(type === "service" ? item.location : `${item.city} ${item.country}`);
  const cost = getCost(item, type);
  const duration = getDuration(item);

  if (category === preferredCategory || includesText(category, preferredCategory)) {
    score += 3;
    reasons.push(`matches your ${preferences.preferredCategory} preference`);
  }

  if (cost > 0 && cost <= Number(preferences.budget)) {
    score += 2;
    reasons.push("fits your budget");
  }

  if (styles.includes(preferredStyle)) {
    score += 3;
    reasons.push(`matches your ${preferences.travelStyle.toLowerCase()} style`);
  }

  if (includesText(location, preferredLocation)) {
    score += 2;
    reasons.push(`matches your preferred location`);
  }

  if (duration > 0 && Math.abs(duration - Number(preferences.tripDuration)) <= 1) {
    score += 1;
    reasons.push("matches your trip duration");
  }

  const itemId = item._id.toString();
  const isFavorite = (user.favorites || []).some((id) => id.toString() === itemId);
  const isRecent = (user.recentlyViewed || []).some((id) => id.toString() === itemId);

  if (type === "destination" && isFavorite) {
    score += 2;
    reasons.push("you saved it as a favorite");
  } else if (type === "destination" && isRecent) {
    score += 1;
    reasons.push("you recently viewed it");
  }

  const matchPercent = Math.min(100, Math.round((score / (maxScore + 2)) * 100));

  return {
    score,
    matchPercent,
    reasons,
    reason: reasons.length
      ? `Recommended because it ${reasons.slice(0, 2).join(" and ")}.`
      : "Recommended based on overall availability and popularity."
  };
};

const savePreferences = async (req, res, statusCode = 200) => {
  const error = validatePreferences(req.body);
  if (error) {
    return res.status(400).json({ message: error });
  }

  const data = {
    user: req.user.userId,
    budget: Number(req.body.budget),
    travelStyle: req.body.travelStyle,
    preferredCategory: req.body.preferredCategory.trim(),
    preferredLocation: req.body.preferredLocation.trim(),
    tripDuration: Number(req.body.tripDuration)
  };

  const preferences = await RecommendationPreference.findOneAndUpdate(
    { user: req.user.userId },
    data,
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );

  return res.status(statusCode).json({
    message: statusCode === 201 ? "Preferences saved successfully" : "Preferences updated successfully",
    preferences
  });
};

exports.getPreferences = async (req, res) => {
  try {
    const preferences = await RecommendationPreference.findOne({ user: req.user.userId });
    res.json({ preferences });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createPreferences = async (req, res) => {
  try {
    const existing = await RecommendationPreference.findOne({ user: req.user.userId });
    if (existing) {
      return res.status(409).json({
        message: "Preferences already exist. Use the update option."
      });
    }
    await savePreferences(req, res, 201);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updatePreferences = async (req, res) => {
  try {
    const existing = await RecommendationPreference.findOne({ user: req.user.userId });
    if (!existing) {
      return res.status(404).json({
        message: "Preferences not found. Save your preferences first."
      });
    }
    await savePreferences(req, res, 200);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getRecommendations = async (req, res) => {
  try {
    const [preferences, user, destinations, services, bookings] = await Promise.all([
      RecommendationPreference.findOne({ user: req.user.userId }),
      User.findById(req.user.userId).select("favorites recentlyViewed"),
      Destination.find(),
      Service.find({ availability: true }),
      Booking.find({ user: req.user.userId }).populate("service", "category location")
    ]);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (!preferences) {
      return res.json({
        preferences: null,
        destinations: [],
        services: [],
        message: "Save your travel preferences to get personalized recommendations."
      });
    }

    const bookedServiceCategories = bookings
      .map((booking) => normalize(booking.service?.category))
      .filter(Boolean);

    const destinationResults = destinations
      .map((item) => ({
        item,
        type: "destination",
        ...scoreItem(item, "destination", preferences, user)
      }))
      .map((result) => {
        if (bookedServiceCategories.includes(normalize(result.item.category))) {
          result.score += 2;
          result.matchPercent = Math.min(100, Math.round((result.score / 17) * 100));
          result.reasons.push("matches your previous booking interests");
          result.reason = `Recommended because it ${result.reasons.slice(0, 2).join(" and ")}.`;
        }
        return result;
      });

    const serviceResults = services.map((item) => ({
      item,
      type: "service",
      ...scoreItem(item, "service", preferences, user)
    })).map((result) => {
      if (bookedServiceCategories.includes(normalize(result.item.category))) {
        result.score += 2;
        result.matchPercent = Math.min(100, Math.round((result.score / 17) * 100));
        result.reasons.push("matches your previous booking interests");
        result.reason = `Recommended because it ${result.reasons.slice(0, 2).join(" and ")}.`;
      }
      return result;
    });

    const sortResults = (a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      const aRating = Number(a.item.rating || 0);
      const bRating = Number(b.item.rating || 0);
      return bRating - aRating;
    };

    destinationResults.sort(sortResults);
    serviceResults.sort(sortResults);

    const recommendations = {
      destinations: destinationResults.slice(0, 6),
      services: serviceResults.slice(0, 6)
    };

    const hasAny = recommendations.destinations.length || recommendations.services.length;

    res.json({
      preferences,
      destinations: recommendations.destinations,
      services: recommendations.services,
      message: hasAny ? "Personalized recommendations generated successfully." : "No recommendations are available right now."
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
