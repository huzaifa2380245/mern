const express = require("express");
const router = express.Router();

const {
    getServices,
    getServiceById,
    addService,
    updateService,
    deleteService,
    getServicesByCategory
} = require("../controllers/serviceController");

// Get all services
router.get("/", getServices);

// Get services by category
router.get("/category/:category", getServicesByCategory);

// Get service by ID
router.get("/:id", getServiceById);

// Add service
router.post("/", addService);

// Update service
router.put("/:id", updateService);

// Delete service
router.delete("/:id", deleteService);

module.exports = router;