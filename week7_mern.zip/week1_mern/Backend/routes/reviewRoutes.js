const express = require("express");
const router = express.Router();

const {
  addReview,
  getReviews,
  getReviewById,
  updateReview,
  deleteReview,
  markHelpful
} = require("../controllers/reviewController");

const authMiddleware = require("../middleware/authMiddleware");

// Get reviews and rating summary
router.get("/", getReviews);

// Add review
router.post("/", authMiddleware, addReview);

// Helpful button
router.patch("/:id/helpful", markHelpful);

// Update review
router.put("/:id", authMiddleware, updateReview);

// Delete review
router.delete("/:id", authMiddleware, deleteReview);

// Get review by ID
router.get("/:id", getReviewById);

module.exports = router;
