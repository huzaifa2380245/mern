const express = require("express");
const router = express.Router();

const {
    createBooking,
    getUserBookings,
    getSingleBooking,
    updateBooking,
    cancelBooking
} = require("../controllers/bookingController");

const authMiddleware = require("../middleware/authMiddleware");

// Create booking
router.post(
    "/",
    authMiddleware,
    createBooking
);

// Get user's bookings
router.get(
    "/",
    authMiddleware,
    getUserBookings
);

// Get single booking
router.get(
    "/:id",
    authMiddleware,
    getSingleBooking
);

// Update booking
router.put(
    "/:id",
    authMiddleware,
    updateBooking
);

// Cancel booking
router.patch(
    "/:id/cancel",
    authMiddleware,
    cancelBooking
);

module.exports = router;