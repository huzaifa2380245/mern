const express = require("express");
const router = express.Router();

const authMiddleware = require("../middleware/authMiddleware");
const {
  getPreferences,
  createPreferences,
  updatePreferences,
  getRecommendations
} = require("../controllers/recommendationController");

router.get("/preferences", authMiddleware, getPreferences);
router.post("/preferences", authMiddleware, createPreferences);
router.put("/preferences", authMiddleware, updatePreferences);
router.get("/", authMiddleware, getRecommendations);

module.exports = router;
