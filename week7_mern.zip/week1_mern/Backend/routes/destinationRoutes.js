const express = require("express");
const router = express.Router();

const {
    getDestinations,
    getDestination,
    createDestination,
    updateDestination,
    deleteDestination,
    getDestinationsByCategory
} = require("../controllers/destinationController");

// Get all destinations
router.get("/", getDestinations);

// Get destinations by category
router.get("/category/:category", getDestinationsByCategory);

// Get single destination
router.get("/:id", getDestination);

// Add destination
router.post("/", createDestination);

// Update destination
router.put("/:id", updateDestination);

// Delete destination
router.delete("/:id", deleteDestination);

module.exports = router;