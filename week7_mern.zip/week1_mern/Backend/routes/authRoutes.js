const express = require("express");
const router = express.Router();

const User = require("../models/User");

const {
    register,
    login,
    getProfile,
    addFavorite,
    removeFavorite,
    getFavorites,
    addRecentlyViewed
} = require("../controllers/authController");

const authMiddleware = require("../middleware/authMiddleware");

// Test Auth API
router.get("/", (req, res) => {
    res.json({
        message: "Auth API is working"
    });
});

// Get users
router.get("/users", async (req, res) => {
    try {
        const users = await User.find().select("-password");

        res.json(users);
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

// Register
router.post("/register", register);

// Login
router.post("/login", login);

// Profile
router.get(
    "/profile",
    authMiddleware,
    getProfile
);

// Add Favorite
router.post(
    "/favorites/:destinationId",
    authMiddleware,
    addFavorite
);

// Remove Favorite
router.delete(
    "/favorites/:destinationId",
    authMiddleware,
    removeFavorite
);

// Get Favorites
router.get(
    "/favorites",
    authMiddleware,
    getFavorites
);

// Recently Viewed
router.post(
    "/recently-viewed/:destinationId",
    authMiddleware,
    addRecentlyViewed
);

module.exports = router;