const mongoose = require("mongoose");

const destinationSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },

    country: {
        type: String,
        required: true
    },

    city: {
        type: String,
        required: true
    },

    description: {
        type: String
    },

    image: {
        type: String
    },

    category: {
        type: String
    },

    rating: {
        type: Number,
        default: 0
    },

    popularity: {
        type: Number,
        default: 0
    },
    budget: {
        type: Number,
        default: 0
    },

    travelStyles: {
        type: [String],
        default: []
    },

    duration: {
        type: Number,
        default: 0
    },


    featured: {
        type: Boolean,
        default: false
    }

});

module.exports = mongoose.model("Destination", destinationSchema);