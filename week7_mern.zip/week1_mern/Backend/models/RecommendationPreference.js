const mongoose = require("mongoose");

const preferenceSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true
    },

    budget: {
      type: Number,
      required: true,
      min: 0
    },

    travelStyle: {
      type: String,
      required: true,
      enum: [
        "Adventure",
        "Relaxation",
        "Cultural",
        "Family",
        "Nature",
        "Luxury",
        "Budget",
        "Sightseeing"
      ]
    },

    preferredCategory: {
      type: String,
      required: true
    },

    preferredLocation: {
      type: String,
      required: true
    },

    tripDuration: {
      type: Number,
      required: true,
      min: 1,
      max: 60
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("RecommendationPreference", preferenceSchema);
