const mongoose = require("mongoose");

const reviewSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    destination: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Destination",
      default: null
    },

    service: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Service",
      default: null
    },

    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },

    reviewText: {
      type: String,
      required: true,
      trim: true,
      minlength: 3,
      maxlength: 1000
    },

    image: {
      type: String,
      default: "",
      trim: true
    },

    helpfulCount: {
      type: Number,
      default: 0,
      min: 0
    }
  },
  {
    timestamps: true
  }
);

reviewSchema.pre("validate", function (next) {
  if (!this.destination && !this.service) {
    return next(new Error("Review must belong to a destination or service"));
  }

  if (this.destination && this.service) {
    return next(new Error("Review cannot belong to both destination and service"));
  }

  next();
});

module.exports = mongoose.model("Review", reviewSchema);
