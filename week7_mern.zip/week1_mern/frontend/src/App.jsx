import { useEffect, useState } from "react";
import {
  BrowserRouter,
  Routes,
  Route,
  useLocation
} from "react-router-dom";

import Profile from "./components/Profile";
import Services from "./components/Services";
import ServiceDetails from "./components/ServiceDetails";
import BookingForm from "./components/BookingForm";
import BookingConfirmation from "./components/BookingConfirmation";
import BookingHistory from "./components/BookingHistory";
import Favorites from "./components/Favorites";
import Dashboard from "./components/Dashboard";
import Login from "./components/Login";

import API from "./services/api";
import "./App.css";

import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Categories from "./components/Categories";
import Destinations from "./components/Destination";
import About from "./components/About";
import DestinationDetails from "./components/DestinationDetails";
import Recommendations from "./components/Recommendations";

function AppContent() {
  const [destinations, setDestinations] = useState([]);
  const location = useLocation();

  useEffect(() => {
    API.get("/destinations")
      .then((res) => {
        setDestinations(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const isLoginPage = location.pathname === "/login";

  return (
    <div className="app">

      {/* Hide Navbar on Login */}
      {!isLoginPage && <Navbar />}

      <Routes>

        {/* Home */}
        <Route
          path="/"
          element={
            <>
              <Hero />
              <Categories />
              <Destinations destinations={destinations} />
            </>
          }
        />

        {/* Services */}
        <Route
          path="/services"
          element={<Services />}
        />

        {/* Service Details */}
        <Route
          path="/service/:id"
          element={<ServiceDetails />}
        />

        {/* Booking Form */}
        <Route
          path="/book/:id"
          element={<BookingForm />}
        />

        {/* Booking Confirmation */}
        <Route
          path="/booking-confirmation/:id"
          element={<BookingConfirmation />}
        />

        {/* Recommendations */}
        <Route
          path="/recommendations"
          element={<Recommendations />}
        />

        {/* Booking History */}
        <Route
          path="/bookings"
          element={<BookingHistory />}
        />

        {/* About */}
        <Route
          path="/about"
          element={<About />}
        />

        {/* Destination Details */}
        <Route
          path="/destination/:id"
          element={<DestinationDetails />}
        />

        {/* Login */}
        <Route
          path="/login"
          element={<Login />}
        />

        {/* Profile */}
        <Route
          path="/profile"
          element={<Profile />}
        />

        {/* Favorites */}
        <Route
          path="/favorites"
          element={<Favorites />}
        />

        {/* Dashboard */}
        <Route
          path="/dashboard"
          element={<Dashboard />}
        />

      </Routes>

      {/* Hide Footer on Login */}
      {!isLoginPage && (
        <footer>
          <h3>Travel Explorer</h3>

          <p>
            Making your dream trips memorable ✈️
          </p>
        </footer>
      )}

    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

export default App;