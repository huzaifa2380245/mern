function Categories() {
  return (
    <section className="categories">
      <h2 className="title">Travel Categories</h2>

      <div className="category-container">
        <div className="category-card">🏖 Beach</div>
        <div className="category-card">🏔 Mountain</div>
        <div className="category-card">🌿 Nature</div>
        <div className="category-card">🏙 City</div>
        <div className="category-card">🏜 Desert</div>
      </div>
    </section>
  );
}

export default Categories;