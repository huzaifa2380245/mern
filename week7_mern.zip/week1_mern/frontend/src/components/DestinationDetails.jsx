import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import API from "../services/api";
import ReviewSection from "./ReviewSection";

function DestinationDetails() {
  const { id } = useParams();

  const [destination, setDestination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    API.get(`/destinations/${id}`)
      .then((res) => {
        setDestination(res.data);
        setLoading(false);

        // Save as recently viewed only if logged in
        const token = localStorage.getItem("token");

        if (token) {
          API.post(`/auth/recently-viewed/${id}`)
            .catch((err) => {
              console.log("Recently viewed error:", err);
            });
        }
      })
      .catch((err) => {
        console.log(err);
        setError("Destination not found.");
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <p>Loading destination...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <>
    <section className="destination-details">

      <img
        src={destination.image}
        alt={destination.name}
      />

      <div>
        <h1>{destination.name}</h1>

        <p>
          📍 {destination.city}, {destination.country}
        </p>

        <p>{destination.description}</p>

        <p>
          🏷️ Category: {destination.category}
        </p>

        <p>
          ⭐ Rating: {destination.rating || 0}
        </p>

        <p>
          🔥 Popularity: {destination.popularity || 0}
        </p>
      </div>

    </section>

    <ReviewSection
      type="destination"
      targetId={id}
    />
    </>
  );
}

export default DestinationDetails;