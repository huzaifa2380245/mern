import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";
import "./Recommendations.css";

const styleOptions = [
  "Adventure",
  "Relaxation",
  "Cultural",
  "Family",
  "Nature",
  "Luxury",
  "Budget",
  "Sightseeing"
];

const categoryOptions = [
  "Mountain",
  "Beach",
  "Nature",
  "Adventure",
  "City Tour",
  "Tour",
  "Cultural",
  "Family"
];

function Recommendations() {
  const [form, setForm] = useState({
    budget: "",
    travelStyle: "Adventure",
    preferredCategory: "Adventure",
    preferredLocation: "Pakistan",
    tripDuration: 5
  });
  const [hasPreferences, setHasPreferences] = useState(false);
  const [destinations, setDestinations] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const loadData = async () => {
    try {
      setLoading(true);
      setError("");

      const preferenceResponse = await API.get("/recommendations/preferences");
      const preferences = preferenceResponse.data.preferences;

      if (preferences) {
        setHasPreferences(true);
        setForm({
          budget: preferences.budget,
          travelStyle: preferences.travelStyle,
          preferredCategory: preferences.preferredCategory,
          preferredLocation: preferences.preferredLocation,
          tripDuration: preferences.tripDuration
        });

        const recommendationResponse = await API.get("/recommendations");
        setDestinations(recommendationResponse.data.destinations || []);
        setServices(recommendationResponse.data.services || []);
      } else {
        setHasPreferences(false);
        setDestinations([]);
        setServices([]);
      }
    } catch (err) {
      setError(err.response?.data?.message || "Could not load recommendations.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((current) => ({ ...current, [name]: value }));
  };

  const savePreferences = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setSaving(true);

    try {
      const payload = {
        ...form,
        budget: Number(form.budget),
        tripDuration: Number(form.tripDuration)
      };

      if (hasPreferences) {
        await API.put("/recommendations/preferences", payload);
        setMessage("Preferences updated successfully.");
      } else {
        await API.post("/recommendations/preferences", payload);
        setHasPreferences(true);
        setMessage("Preferences saved successfully.");
      }

      const response = await API.get("/recommendations");
      setDestinations(response.data.destinations || []);
      setServices(response.data.services || []);
    } catch (err) {
      setError(err.response?.data?.message || "Could not save preferences.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <main className="recommendations-page"><p>Loading recommendations...</p></main>;
  }

  return (
    <main className="recommendations-page">
      <section className="recommendation-hero">
        <div>
          <p className="eyebrow">PERSONALIZED FOR YOU</p>
          <h1>Find trips that fit your travel style</h1>
          <p>
            Tell us your preferences and we will rank destinations and services using simple matching rules.
          </p>
        </div>
      </section>

      {error && <div className="recommendation-error">{error}</div>}
      {message && <div className="recommendation-success">{message}</div>}

      <section className="preferences-card">
        <div className="section-heading">
          <div>
            <h2>Your Travel Preferences</h2>
            <p>These settings are stored in MongoDB and used for your recommendations.</p>
          </div>
        </div>

        <form onSubmit={savePreferences} className="preferences-form">
          <label>
            Budget (PKR)
            <input
              name="budget"
              type="number"
              min="0"
              value={form.budget}
              onChange={handleChange}
              placeholder="50000"
              required
            />
          </label>

          <label>
            Travel Style
            <select name="travelStyle" value={form.travelStyle} onChange={handleChange}>
              {styleOptions.map((style) => <option key={style}>{style}</option>)}
            </select>
          </label>

          <label>
            Preferred Category
            <select name="preferredCategory" value={form.preferredCategory} onChange={handleChange}>
              {categoryOptions.map((category) => <option key={category}>{category}</option>)}
            </select>
          </label>

          <label>
            Preferred Location
            <input
              name="preferredLocation"
              value={form.preferredLocation}
              onChange={handleChange}
              placeholder="Pakistan"
              required
            />
          </label>

          <label>
            Trip Duration (days)
            <input
              name="tripDuration"
              type="number"
              min="1"
              max="60"
              value={form.tripDuration}
              onChange={handleChange}
              required
            />
          </label>

          <button type="submit" disabled={saving}>
            {saving ? "Saving..." : hasPreferences ? "Update Preferences" : "Save Preferences"}
          </button>
        </form>
      </section>

      <section className="recommendation-results">
        <div className="section-heading">
          <div>
            <h2>Recommended Destinations</h2>
            <p>Higher matches are shown first.</p>
          </div>
        </div>

        {!hasPreferences ? (
          <div className="empty-recommendations">Save your preferences above to get recommendations.</div>
        ) : destinations.length === 0 ? (
          <div className="empty-recommendations">No destination recommendations are available right now.</div>
        ) : (
          <div className="recommendation-grid">
            {destinations.map((result) => (
              <article key={result.item._id} className="recommendation-card">
                {result.item.image && <img src={result.item.image} alt={result.item.name} />}
                <div className="recommendation-card-body">
                  <div className="match-badge">{result.matchPercent}% Match</div>
                  <h3>{result.item.name}</h3>
                  <p className="muted">📍 {result.item.city}, {result.item.country}</p>
                  <p>{result.item.description}</p>
                  <p className="reason">{result.reason}</p>
                  <Link to={`/destination/${result.item._id}`} className="recommendation-button">View Destination</Link>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="recommendation-results">
        <div className="section-heading">
          <div>
            <h2>Recommended Services</h2>
            <p>Tour and travel services selected from your preferences.</p>
          </div>
        </div>

        {!hasPreferences ? (
          <div className="empty-recommendations">Save your preferences above to get service recommendations.</div>
        ) : services.length === 0 ? (
          <div className="empty-recommendations">No service recommendations are available right now.</div>
        ) : (
          <div className="recommendation-grid">
            {services.map((result) => (
              <article key={result.item._id} className="recommendation-card">
                {result.item.image && <img src={result.item.image} alt={result.item.serviceName} />}
                <div className="recommendation-card-body">
                  <div className="match-badge">{result.matchPercent}% Match</div>
                  <h3>{result.item.serviceName}</h3>
                  <p className="muted">📍 {result.item.location}</p>
                  <p>💰 PKR {result.item.price}</p>
                  <p>⭐ {result.item.rating || 0}</p>
                  <p className="reason">{result.reason}</p>
                  <Link to={`/service/${result.item._id}`} className="recommendation-button">View Service</Link>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}

export default Recommendations;
