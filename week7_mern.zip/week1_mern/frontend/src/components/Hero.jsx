function Hero() {
  return (
    <section className="hero">
      <div className="overlay">
        <span className="eyebrow">Where Next?</span>
        <h1>Explore The World 🌎</h1>
        <p>
          Discover amazing places, beautiful landscapes, and unforgettable
          experiences.
        </p>
        <button>Start Exploring</button>
      </div>
    </section>
  );
}

export default Hero;