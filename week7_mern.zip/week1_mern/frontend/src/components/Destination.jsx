import { useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Destinations({ destinations }) {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [favorites, setFavorites] = useState([]);

  const categories = [
    "All",
    ...new Set(
      destinations
        .map((item) => item.category)
        .filter((item) => item)
    ),
  ];

  const filteredDestinations = destinations.filter((item) => {
    const searchText = search.toLowerCase();

    const matchesSearch =
      item.name.toLowerCase().includes(searchText) ||
      item.country.toLowerCase().includes(searchText) ||
      item.city.toLowerCase().includes(searchText);

    const matchesCategory =
      category === "All" || item.category === category;

    return matchesSearch && matchesCategory;
  });

  const featuredDestinations = filteredDestinations.filter(
    (item) => item.featured
  );

  const toggleFavorite = async (destinationId) => {
    const token = localStorage.getItem("token");

    if (!token) {
      window.location.href = "/login";
      return;
    }

    try {
      if (favorites.includes(destinationId)) {
        await API.delete(`/auth/favorites/${destinationId}`);

        setFavorites(
          favorites.filter((id) => id !== destinationId)
        );
      } else {
        await API.post(`/auth/favorites/${destinationId}`);

        setFavorites([
          ...favorites,
          destinationId
        ]);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const DestinationCard = ({ item }) => (
    <div className="card" key={item._id}>
      <img
        src={item.image}
        alt={item.name}
      />

      <div className="card-content">
        <h3>{item.name}</h3>

        <p className="location">
          📍 {item.city}, {item.country}
        </p>

        <p>{item.description}</p>

        <p>
          ⭐ Rating: {item.rating || 0}
        </p>

        <p>
          🔥 Popularity: {item.popularity || 0}
        </p>

        <button
          onClick={() => toggleFavorite(item._id)}
          className="favorite-btn"
        >
          {favorites.includes(item._id)
            ? "❤️ Saved"
            : "🤍 Favorite"}
        </button>

        <Link
          to={`/destination/${item._id}`}
          className="view-btn"
        >
          View Details
        </Link>
      </div>
    </div>
  );

  return (
    <section className="destinations">

      {/* Search */}
      <div className="search-section">
        <h2 className="title">
          Explore Destinations
        </h2>

        <input
          type="text"
          placeholder="Search destinations..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
        />
      </div>

      {/* Categories */}
      <div className="category-filter">
        {categories.map((item) => (
          <button
            key={item}
            onClick={() => setCategory(item)}
            className={
              category === item
                ? "active-category"
                : ""
            }
          >
            {item}
          </button>
        ))}
      </div>

      {/* Featured */}
      <h2 className="title">
        Featured Destinations
      </h2>

      <div className="card-container">
        {featuredDestinations.length > 0 ? (
          featuredDestinations.map((item) => (
            <DestinationCard
              key={item._id}
              item={item}
            />
          ))
        ) : (
          <p>No featured destinations found.</p>
        )}
      </div>

      {/* All */}
      <h2 className="title">
        All Destinations
      </h2>

      <div className="card-container">
        {filteredDestinations.length > 0 ? (
          filteredDestinations.map((item) => (
            <DestinationCard
              key={item._id}
              item={item}
            />
          ))
        ) : (
          <p>No destinations found.</p>
        )}
      </div>

    </section>
  );
}

export default Destinations;