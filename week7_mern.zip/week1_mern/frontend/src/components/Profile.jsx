import { useEffect, useState } from "react";
import API from "../services/api";
import "./Profile.css";

function Profile() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    API.get("/auth/profile")
      .then((res) => {
        setUser(res.data.user);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  if (!user) {
    return <p>Loading profile...</p>;
  }

  return (
    <div className="profile-page">

      <div className="profile-card">

        <h1>My Profile</h1>

        <div className="profile-image">
          {user.profileImage ? (
            <img
              src={user.profileImage}
              alt={user.name}
            />
          ) : (
            <div className="profile-placeholder">
              👤
            </div>
          )}
        </div>

        <h2>{user.name}</h2>

        <p>
          <strong>Email:</strong> {user.email}
        </p>

        <p>
          <strong>Bio:</strong>{" "}
          {user.bio || "No bio added yet."}
        </p>

      </div>

    </div>
  );
}

export default Profile;