import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Services() {
  const [services, setServices] = useState([]);
  const [category, setCategory] = useState("All");

  useEffect(() => {
    API.get("/services")
      .then((res) => {
        setServices(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const categories = [
    "All",
    ...new Set(services.map((service) => service.category))
  ];

  const filteredServices =
    category === "All"
      ? services
      : services.filter(
          (service) => service.category === category
        );

  return (
    <section className="services-page">

      <h1 className="title">Travel Services</h1>

      <p className="services-subtitle">
        Choose a service and start planning your next trip.
      </p>

      {/* Category Filter */}
      <div className="category-filter">
        {categories.map((item) => (
          <button
            key={item}
            onClick={() => setCategory(item)}
            className={
              category === item
                ? "active-category"
                : ""
            }
          >
            {item}
          </button>
        ))}
      </div>

      {/* Services */}
      <div className="card-container">

        {filteredServices.length > 0 ? (
          filteredServices.map((service) => (
            <div className="card" key={service._id}>

              <img
                src={service.image}
                alt={service.serviceName}
              />

              <div className="card-content">

                <h3>{service.serviceName}</h3>

                <p>
                  📍 {service.location}
                </p>

                <p>
                  🏷️ {service.category}
                </p>

                <p>
                  ⭐ Rating: {service.rating}
                </p>

                <p>
                  💰 PKR {service.price}
                </p>

                <p>
                  {service.availability
                    ? "✅ Available"
                    : "❌ Not Available"}
                </p>

                <Link
                  to={`/service/${service._id}`}
                  className="view-btn"
                >
                  View Details
                </Link>

              </div>
            </div>
          ))
        ) : (
          <p>No services available.</p>
        )}

      </div>

    </section>
  );
}

export default Services;