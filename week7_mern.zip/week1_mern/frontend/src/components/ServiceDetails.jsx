import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import API from "../services/api";
import ReviewSection from "./ReviewSection";

function ServiceDetails() {
  const { id } = useParams();

  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.get(`/services/${id}`)
      .then((res) => {
        setService(res.data);
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <p>Loading service...</p>;
  }

  if (!service) {
    return <p>Service not found.</p>;
  }

  return (
    <>
    <section className="destination-details">

      <img
        src={service.image}
        alt={service.serviceName}
      />

      <div>
        <h1>{service.serviceName}</h1>

        <p>📍 {service.location}</p>

        <p>{service.description}</p>

        <p>🏷️ Category: {service.category}</p>

        <p>⭐ Rating: {service.rating}</p>

        <p>💰 Price: PKR {service.price}</p>

        <p>
          {service.availability
            ? "✅ Available"
            : "❌ Not Available"}
        </p>

        <h3>Features</h3>

        <ul>
          {service.features.map((feature, index) => (
            <li key={index}>
              {feature}
            </li>
          ))}
        </ul>

        {service.availability && (
          <Link
            to={`/book/${service._id}`}
            className="view-btn"
          >
            Book Now
          </Link>
        )}

      </div>

    </section>

    <ReviewSection
      type="service"
      targetId={id}
    />
    </>
  );
}

export default ServiceDetails;