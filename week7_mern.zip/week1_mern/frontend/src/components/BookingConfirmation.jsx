import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import API from "../services/api";

function BookingConfirmation() {
  const { id } = useParams();

  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");

    API.get(`/bookings/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then((res) => {
        setBooking(res.data);
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <p>Loading confirmation...</p>;
  }

  if (!booking) {
    return <p>Booking not found.</p>;
  }

  return (
    <section className="booking-page">

      <div className="booking-card">

        <h1>🎉 Booking Confirmed!</h1>

        <p>
          Your booking has been successfully submitted.
        </p>

        <hr />

        <h2>
          {booking.service?.serviceName}
        </h2>

        <p>
          📍 {booking.service?.location}
        </p>

        <p>
          🆔 Booking ID: <strong>{booking.bookingId}</strong>
        </p>

        <p>
          📅 Date:{" "}
          {new Date(booking.bookingDate).toLocaleDateString()}
        </p>

        <p>
          👥 People: {booking.numberOfPeople}
        </p>

        <p>
          💰 Total Price: PKR {booking.totalPrice}
        </p>

        <p>
          📌 Status: {booking.bookingStatus}
        </p>

        {booking.specialRequest && (
          <p>
            📝 Special Request: {booking.specialRequest}
          </p>
        )}

        <Link
          to="/bookings"
          className="view-btn"
        >
          View My Bookings
        </Link>

      </div>

    </section>
  );
}

export default BookingConfirmation;