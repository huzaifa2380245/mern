import { useEffect, useMemo, useState } from "react";
import API from "../services/api";
import "./ReviewSection.css";

function Stars({ value, interactive = false, onChange }) {
  return (
    <div className="review-stars" aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type={interactive ? "button" : "button"}
          className={star <= value ? "star active" : "star"}
          onClick={() => interactive && onChange?.(star)}
          disabled={!interactive}
        >
          ★
        </button>
      ))}
    </div>
  );
}

function ReviewSection({ type, targetId, title = "Reviews & Ratings" }) {
  const [reviews, setReviews] = useState([]);
  const [summary, setSummary] = useState({
    averageRating: 0,
    totalReviews: 0,
    ratingDistribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
  });
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState("");
  const [image, setImage] = useState("");
  const [filter, setFilter] = useState("all");
  const [editingId, setEditingId] = useState(null);
  const [editRating, setEditRating] = useState(5);
  const [editText, setEditText] = useState("");
  const [editImage, setEditImage] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  const getCurrentUserId = () => {
    const savedId = localStorage.getItem("userId");
    if (savedId) return savedId;

    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      return payload.userId || null;
    } catch {
      return null;
    }
  };

  const currentUser = getCurrentUserId();

  const loadReviews = async () => {
    try {
      setLoading(true);
      const query = type === "destination" ? `?destination=${targetId}` : `?service=${targetId}`;
      const res = await API.get(`/reviews${query}`);
      setReviews(res.data.reviews || []);
      setSummary(
        res.data.summary || {
          averageRating: 0,
          totalReviews: 0,
          ratingDistribution: { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 }
        }
      );
    } catch (err) {
      setError(err.response?.data?.message || "Could not load reviews.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReviews();
  }, [targetId, type]);

  const filteredReviews = useMemo(() => {
    if (filter === "all") return reviews;
    return reviews.filter((review) => review.rating === Number(filter));
  }, [reviews, filter]);

  const submitReview = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!token) {
      setError("Please login to submit a review.");
      return;
    }

    if (!rating) {
      setError("Please select a rating.");
      return;
    }

    if (!reviewText.trim()) {
      setError("Review text is required.");
      return;
    }

    try {
      const data = {
        rating,
        reviewText,
        image
      };
      data[type] = targetId;

      await API.post("/reviews", data);

      setRating(5);
      setReviewText("");
      setImage("");
      setMessage("Review submitted successfully.");
      await loadReviews();
    } catch (err) {
      setError(err.response?.data?.message || "Could not submit review.");
    }
  };

  const startEdit = (review) => {
    setEditingId(review._id);
    setEditRating(review.rating);
    setEditText(review.reviewText);
    setEditImage(review.image || "");
    setError("");
    setMessage("");
  };

  const saveEdit = async (id) => {
    setError("");
    setMessage("");

    if (!editRating || !editText.trim()) {
      setError("Rating and review text are required.");
      return;
    }

    try {
      await API.put(`/reviews/${id}`, {
        rating: editRating,
        reviewText: editText,
        image: editImage
      });

      setEditingId(null);
      setMessage("Review updated successfully.");
      await loadReviews();
    } catch (err) {
      setError(err.response?.data?.message || "Could not update review.");
    }
  };

  const deleteReview = async (id) => {
    if (!window.confirm("Delete this review?")) return;

    try {
      await API.delete(`/reviews/${id}`);
      setMessage("Review deleted successfully.");
      await loadReviews();
    } catch (err) {
      setError(err.response?.data?.message || "Could not delete review.");
    }
  };

  const markHelpful = async (id) => {
    try {
      const res = await API.patch(`/reviews/${id}/helpful`);
      setReviews((current) =>
        current.map((review) =>
          review._id === id
            ? { ...review, helpfulCount: res.data.helpfulCount }
            : review
        )
      );
    } catch (err) {
      setError(err.response?.data?.message || "Could not mark review as helpful.");
    }
  };

  const getPercentage = (count) => {
    if (!summary.totalReviews) return 0;
    return Math.round((count / summary.totalReviews) * 100);
  };

  return (
    <section className="reviews-section">
      <div className="reviews-header">
        <h2>{title}</h2>
        <p>Share your experience and help other travelers.</p>
      </div>

      {message && <div className="review-success">{message}</div>}
      {error && <div className="review-error">{error}</div>}

      <div className="rating-summary">
        <div className="rating-main">
          <div className="average-rating">{summary.averageRating.toFixed(1)}</div>
          <Stars value={Math.round(summary.averageRating)} />
          <div>{summary.totalReviews} Reviews</div>
        </div>

        <div className="rating-distribution">
          {[5, 4, 3, 2, 1].map((number) => {
            const count = summary.ratingDistribution?.[number] || 0;
            return (
              <div className="distribution-row" key={number}>
                <span>{number} ★</span>
                <div className="distribution-bar">
                  <div style={{ width: `${getPercentage(count)}%` }} />
                </div>
                <span>{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {token ? (
        <form className="review-form" onSubmit={submitReview}>
          <h3>Write a Review</h3>
          <label>Rating</label>
          <Stars value={rating} interactive onChange={setRating} />

          <label htmlFor="reviewText">Review</label>
          <textarea
            id="reviewText"
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Write your experience..."
            maxLength={1000}
            required
          />

          <label htmlFor="reviewImage">Image URL (optional)</label>
          <input
            id="reviewImage"
            type="url"
            value={image}
            onChange={(e) => setImage(e.target.value)}
            placeholder="https://..."
          />

          <button className="review-submit" type="submit">
            Submit Review
          </button>
        </form>
      ) : (
        <div className="login-review-note">Login to submit, edit or delete your review.</div>
      )}

      <div className="review-list-header">
        <h3>Customer Reviews</h3>
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">All Ratings</option>
          <option value="5">5 Stars</option>
          <option value="4">4 Stars</option>
          <option value="3">3 Stars</option>
          <option value="2">2 Stars</option>
          <option value="1">1 Star</option>
        </select>
      </div>

      {loading ? (
        <p>Loading reviews...</p>
      ) : filteredReviews.length === 0 ? (
        <p className="no-reviews">No reviews yet. Be the first to review!</p>
      ) : (
        <div className="review-list">
          {filteredReviews.map((review) => {
            const ownerId = review.user?._id || review.user;
            const isOwner = token && currentUser && ownerId?.toString() === currentUser;

            return (
              <article className="review-card" key={review._id}>
                {editingId === review._id ? (
                  <div className="edit-review-form">
                    <div className="review-card-top">
                      <strong>{review.user?.name || "Traveler"}</strong>
                      <Stars value={editRating} interactive onChange={setEditRating} />
                    </div>
                    <textarea
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      maxLength={1000}
                    />
                    <input
                      type="url"
                      value={editImage}
                      onChange={(e) => setEditImage(e.target.value)}
                      placeholder="Image URL (optional)"
                    />
                    <div className="review-actions">
                      <button className="review-submit" onClick={() => saveEdit(review._id)}>Save</button>
                      <button className="review-cancel" onClick={() => setEditingId(null)}>Cancel</button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="review-card-top">
                      <div>
                        <strong>{review.user?.name || "Traveler"}</strong>
                        <Stars value={review.rating} />
                      </div>
                      <span className="review-date">
                        {new Date(review.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="review-text">{review.reviewText}</p>

                    {review.image && (
                      <img className="review-image" src={review.image} alt="Review" />
                    )}

                    <div className="review-bottom">
                      <button className="helpful-btn" onClick={() => markHelpful(review._id)}>
                        👍 Helpful ({review.helpfulCount || 0})
                      </button>

                      {isOwner && (
                        <div className="review-actions">
                          <button onClick={() => startEdit(review)}>Edit</button>
                          <button className="delete-btn" onClick={() => deleteReview(review._id)}>Delete</button>
                        </div>
                      )}
                    </div>
                  </>
                )}
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}

export default ReviewSection;
