import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Favorites() {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    API.get("/auth/favorites")
      .then((res) => {
        setFavorites(res.data.favorites);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <section className="destinations">
      <h1 className="title">❤️ My Favorites</h1>

      <div className="card-container">
        {favorites.length > 0 ? (
          favorites.map((item) => (
            <div className="card" key={item._id}>
              <img
                src={item.image}
                alt={item.name}
              />

              <div className="card-content">
                <h3>{item.name}</h3>

                <p>
                  📍 {item.city}, {item.country}
                </p>

                <p>
                  ⭐ Rating: {item.rating || 0}
                </p>

                <Link
                  to={`/destination/${item._id}`}
                  className="view-btn"
                >
                  View Details
                </Link>
              </div>
            </div>
          ))
        ) : (
          <p>No favorite destinations yet.</p>
        )}
      </div>
    </section>
  );
}

export default Favorites;