import { useEffect, useState } from "react";
import API from "../services/api";

function BookingHistory() {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");

    API.get("/bookings", {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then((res) => setBookings(res.data))
      .catch((err) => console.log(err));
  }, []);

  return (
    <section className="booking-page">
      <h1>My Bookings</h1>

      {bookings.length === 0 ? (
        <p>No bookings found.</p>
      ) : (
        bookings.map((booking) => (
          <div className="booking-card" key={booking._id}>
            <h2>{booking.service?.serviceName}</h2>

            <p>🆔 Booking ID: {booking.bookingId}</p>

            <p>
              📅 Date:{" "}
              {new Date(booking.bookingDate).toLocaleDateString()}
            </p>

            <p>👥 People: {booking.numberOfPeople}</p>

            <p>💰 Price: PKR {booking.totalPrice}</p>

            <p>📌 Status: {booking.bookingStatus}</p>
          </div>
        ))
      )}
    </section>
  );
}

export default BookingHistory;