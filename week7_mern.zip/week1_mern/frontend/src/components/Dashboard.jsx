import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import API from "../services/api";

function Dashboard() {
  const [user, setUser] = useState(null);
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    API.get("/auth/profile")
      .then((res) => {
        setUser(res.data.user);
      })
      .catch((err) => {
        console.log(err);
      });

    API.get("/auth/favorites")
      .then((res) => {
        setFavorites(res.data.favorites);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  if (!user) {
    return <p>Loading dashboard...</p>;
  }

  return (
    <section className="dashboard">

      <div className="dashboard-header">
        <h1>Welcome, {user.name}! 👋</h1>
        <p>Your personalized travel dashboard</p>
      </div>

      <div className="stats">

        <div className="stat-card">
          <h2>{favorites.length}</h2>
          <p>❤️ Favorite Destinations</p>
        </div>

        <div className="stat-card">
          <h2>{user.recentlyViewed?.length || 0}</h2>
          <p>👀 Recently Viewed</p>
        </div>

      </div>

      <div className="dashboard-section">

        <h2>❤️ Your Favorites</h2>

        <div className="card-container">

          {favorites.length > 0 ? (
            favorites.map((item) => (
              <div className="card" key={item._id}>

                <img
                  src={item.image}
                  alt={item.name}
                />

                <div className="card-content">

                  <h3>{item.name}</h3>

                  <p>
                    📍 {item.city}, {item.country}
                  </p>

                  <Link
                    to={`/destination/${item._id}`}
                    className="view-btn"
                  >
                    View Details
                  </Link>

                </div>

              </div>
            ))
          ) : (
            <p>No favorite destinations yet.</p>
          )}

        </div>

      </div>

      <div className="dashboard-links">

        <Link to="/profile">
          👤 My Profile
        </Link>

        <Link to="/favorites">
          ❤️ My Favorites
        </Link>

      </div>

    </section>
  );
}

export default Dashboard;