function About() {
  return (
    <section className="about">
      <span className="eyebrow">Our Story</span>
      <h1>Built By Wanderers, For Wanderers.</h1>
      <p>
        Travel Explorer started as a shared notebook of places we'd actually
        visited — no stock listings, no filler. Today it's the same idea,
        just easier to search.
      </p>

      <div className="stats-row">
        <div className="stat">
          <h2>48</h2>
          <p>Countries Mapped</p>
        </div>
        <div className="stat">
          <h2>12k+</h2>
          <p>Trips Planned</p>
        </div>
        <div className="stat">
          <h2>4.8/5</h2>
          <p>Traveler Rating</p>
        </div>
      </div>

      <div className="mission">
        <div className="mission-block">
          <h3>What We Believe</h3>
          <p>
            The best trips aren't the most photographed ones — they're the
            ones that fit who you actually are.
          </p>
        </div>
        <div className="mission-block">
          <h3>How We Pick Places</h3>
          <p>
            Every destination here has been visited and checked before it
            makes the list.
          </p>
        </div>
      </div>
    </section>
  );
}

export default About;