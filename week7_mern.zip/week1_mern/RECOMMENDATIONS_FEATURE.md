# Personalized Travel Recommendation System

## Added Features
- User travel preferences: budget, travel style, preferred category, preferred location, trip duration.
- MongoDB `RecommendationPreference` model with one preferences record per user.
- Recommendation APIs for saving, updating, reading preferences, and generating recommendations.
- Scoring rules for category, budget, travel style, location, duration, favorites, recently viewed destinations, and previous booking interests.
- Recommended destinations and services sorted by relevance.
- Match percentage and recommendation reason shown in React.
- Loading, empty-state, invalid-preference, and API error handling.

## API Endpoints
- `GET /api/recommendations/preferences`
- `POST /api/recommendations/preferences`
- `PUT /api/recommendations/preferences`
- `GET /api/recommendations`

All recommendation endpoints require a JWT bearer token.

## Frontend
Open `/recommendations` after logging in. The navbar shows it as **For You**.

## Demo Data
The existing destination and service seed files now include budget/travel-style/duration data so recommendations have meaningful matches when the sample data is loaded again.
