import { Link } from "react-router-dom";

function Navbar() {
  const token = localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    window.location.href = "/login";
  };

  return (
    <nav className="navbar">

      <h2 className="brand">🌍 Travel Explorer</h2>

      <div className="nav-links">

        <Link to="/">
          Home
        </Link>

        <Link to="/services">
          Services
        </Link>

        <Link to="/about">
          About
        </Link>

        {token && (
          <Link to="/bookings">
            My Bookings
          </Link>
        )}

        {token && (
          <Link to="/profile">
            Profile
          </Link>
        )}

        {!token ? (
          <Link to="/login">
            Login
          </Link>
        ) : (
          <button onClick={handleLogout}>
            Logout
          </button>
        )}

      </div>

    </nav>
  );
}

export default Navbar;