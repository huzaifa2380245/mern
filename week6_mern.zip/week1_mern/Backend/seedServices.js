const mongoose = require("mongoose");
require("dotenv").config();

const Service = require("./models/Service");

const services = [
    {
        serviceName: "Hunza Valley Tour",
        category: "Tour",
        location: "Hunza, Pakistan",
        description: "A beautiful tour of Hunza Valley including major attractions.",
        image: "https://images.unsplash.com/photo-1587474260584-136574528ed5",
        price: 25000,
        rating: 4.8,
        availability: true,
        features: [
            "Hotel",
            "Transport",
            "Tour Guide",
            "Sightseeing"
        ]
    },
    {
        serviceName: "Skardu Adventure Tour",
        category: "Adventure",
        location: "Skardu, Pakistan",
        description: "Explore the mountains and beautiful landscapes of Skardu.",
        image: "https://images.unsplash.com/photo-1589553416260-f586c8f1514f",
        price: 30000,
        rating: 4.7,
        availability: true,
        features: [
            "Transport",
            "Camping",
            "Guide",
            "Sightseeing"
        ]
    },
    {
        serviceName: "Islamabad City Tour",
        category: "City Tour",
        location: "Islamabad, Pakistan",
        description: "Discover the famous attractions of Islamabad.",
        image: "https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83",
        price: 10000,
        rating: 4.5,
        availability: true,
        features: [
            "Transport",
            "Guide",
            "City Tour"
        ]
    }
];

async function seedServices() {
    try {
        await mongoose.connect(process.env.MONGO_URI);

        console.log("MongoDB connected");

        await Service.deleteMany();

        await Service.insertMany(services);

        console.log("Services added successfully");

        process.exit();
    } catch (error) {
        console.log(error);
        process.exit(1);
    }
}

seedServices();