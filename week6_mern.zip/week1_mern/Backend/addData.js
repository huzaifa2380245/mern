const mongoose = require("mongoose");
require("dotenv").config();

const Destination = require("./models/Destination");


const destinations = [
    {
        name: "Hunza Valley",
        country: "Pakistan",
        city: "Gilgit Baltistan",
        description: "A beautiful mountain valley famous for its landscapes and peaceful environment.",
        image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa",
        category: "Mountain",
        featured: true
    },
    {
        name: "Bali Island",
        country: "Indonesia",
        city: "Denpasar",
        description: "A tropical destination famous for beaches, temples, and culture.",
        image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4",
        category: "Beach",
        featured: true
    }
];


mongoose
.connect(process.env.MONGO_URI)
.then(async()=>{

    await Destination.deleteMany();

    await Destination.insertMany(destinations);

    console.log("Sample data added");

    mongoose.connection.close();

})
.catch((error)=>{
    console.log(error);
});